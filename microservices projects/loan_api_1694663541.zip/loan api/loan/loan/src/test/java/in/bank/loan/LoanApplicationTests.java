package in.bank.loan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = LoanApplication.class)
class LoanApplicationTests {

	@Test
	void contextLoads() {
	}

}
