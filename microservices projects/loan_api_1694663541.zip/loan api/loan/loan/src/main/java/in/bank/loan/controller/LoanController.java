package in.bank.loan.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.bank.loan.config.LoanConfigService;
import in.bank.loan.models.ConfigProp;
import in.bank.loan.models.CustomerDetails;
import in.bank.loan.models.Loan;
import in.bank.loan.repository.LoanRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/loans")
public class LoanController {

   

    @Autowired
    LoanConfigService loanConfig;

    private Object loanConfig2;

    @PostMapping
    public List<Loan> getLoanDetailsForCustomer(@RequestBody LoanRequest request) {
        try {
            return LoanRepository.findByCustomerId(request.getCustomerId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping("/loan/configProps")
    public byte[] getPropertyDetails() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        loanConfig2 = null;
        ConfigProp properties = new ConfigProp(((ConfigProp) loanConfig2).getMsg(),
                ((ConfigProp) loanConfig2).getBuildVersion(), ((ConfigProp) loanConfig2).getMailDetails(),
                ((ConfigProp) loanConfig2).getActiveBranches());
        byte[] jsonStr = objectMapper.writeValueAsBytes(properties);
        return jsonStr;
    }

    @PostMapping("/profile")
    @CircuitBreaker(name = "getCustomerDetails", fallbackMethod = "getCustomerDetailsFallback")
    public CustomerDetails getCustomerDetails(@RequestBody CustomerDetails customer) {
        Loan loan = new Loan();
        
        CustomerDetails customerDetails = new CustomerDetails();
        customerDetails.setLoan(loan);
        return customerDetails;
    }
}