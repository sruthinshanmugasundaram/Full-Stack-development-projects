package in.bank.loan.models;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerDetails {
	
	private Loan loan1;
	private List<Loan> loan;
	

}
