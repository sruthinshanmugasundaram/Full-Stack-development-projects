package in.bank.insurance.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.bank.insurance.models.Insurance;
import in.bank.insurance.repository.InsuranceRepository;


@RestController
@RequestMapping("/insurance")
public class InsuranceController {

    @Autowired
    private InsuranceRepository insuranceRepository;

    

    @GetMapping("/hello")
    public String helloPage() {
        return "hello";
    }

    @GetMapping("/")
    public Iterable<Insurance> getInsuranceList() {
        return insuranceRepository.findAll();
    }

    @PostMapping("/")
    public ResponseEntity<?> getInsuranceDetails(@RequestBody CustomerRequest request) {
        int customerId = request.getCustomerId();
        Insurance insuranceDetails = insuranceRepository.findByCustomerId(customerId);

        if (insuranceDetails != null) {
            return ResponseEntity.ok(insuranceDetails);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    public class CustomerRequest {
        private int customerId;

        public int getCustomerId() {
            return customerId;
        }

        public void setCustomerId(int customerId) {
            this.customerId = customerId;
        }
    }
}
