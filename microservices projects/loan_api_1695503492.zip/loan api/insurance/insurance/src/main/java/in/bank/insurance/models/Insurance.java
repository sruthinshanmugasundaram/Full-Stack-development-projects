package in.bank.insurance.models;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
public class Insurance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name = "insurance_number")
    private Long insuranceNumber;
    
    @Column(name = "customer_id")
    private int customerId;
    
    @Column(name = "insurance_type")
    private String insuranceType;
    
    @Column(name = "insured_amount")
    private double insuredAmount;
    
    @Column(name = "insurance_end_date")
    private Date insuranceEndDate;

	public static Insurance getInsuranceDetailsByCustomerId(int customerId2) {
		// TODO Auto-generated method stub
		return null;
	}
}