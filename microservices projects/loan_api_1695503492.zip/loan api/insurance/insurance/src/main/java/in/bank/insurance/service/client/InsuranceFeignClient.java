package in.bank.insurance.service.client;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.cloud.openfeign.FeignClient;
import in.bank.insurance.models.Insurance;

@FeignClient(name = "insurance-service", url = "${insurance-service-url}")
public interface InsuranceFeignClient {

    @GetMapping("/insurance/{customerId}")
    Insurance getInsuranceDetails(@PathVariable("customerId") int customerId);
}