package in.bank.accounts.repository;

import in.bank.accounts.models.Accounts;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
@Repository
public interface AccountsRepository extends JpaRepository<Accounts, Long> {
	

	Accounts findByCustomerId(int customerId);
	}
