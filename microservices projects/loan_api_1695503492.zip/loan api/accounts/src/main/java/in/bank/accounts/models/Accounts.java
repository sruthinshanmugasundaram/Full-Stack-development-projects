package in.bank.accounts.models;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString; 
@Entity() 
@Getter 
@Setter 
@ToString 
public class Accounts { 
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO) 
	@Column(name="account_number") 
	private int accountNumber; 
	
	@Column(name="customer_id") 
	private int customerId; 
	
	@Column(name="account_type") 
	private String accountType; 
	
	@Column(name="branch") 
	private String branch; 
	
	@Column(name="created date") 
	private LocalDate createdDate;
}