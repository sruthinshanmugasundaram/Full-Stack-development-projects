package in.bank.accounts.controller;

import java.util.List;

import javax.smartcardio.Card;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.core.net.ObjectWriter;
import in.bank.accounts.config.Insurance_policyConfigService;
import in.bank.accounts.models.ConfigProp;
import in.bank.accounts.models.Accounts;
import in.bank.accounts.repository.AccountsRepository;
import in.bank.loan.models.CustomerDetails;
import in.bank.loan.models.Loan;
import in.bank.cards.models.Cards;
import in.bank.cards.service.client.CardsFeignClient;
import in.bank.accounts.config.AccountsConfigServer;
import in.bank.insurance.models.Insurance;
import in.bank.insurance.service.client.InsuranceFeignClient
import in.bank.loan.service.client.LoanFeignClient;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;


@RestController
@RequestMapping("/accounts")
public class AccountsController {

    private static final Logger logger = LoggerFactory.getLogger(AccountsController.class);

    @Autowired
    private AccountsRepository accountsRepository;

    @Autowired
    private CardsFeignClient cardsFeignClient;

    @Autowired
    private LoanFeignClient loanFeignClient;

    @Autowired
    private InsuranceFeignClient insuranceFeignClient;

    @Autowired
    private AccountsConfigServer accountsConfig;

    @PostMapping("/customer/{customerId}")
    public ResponseEntity<CustomerDetails> getCustomerDetails(@PathVariable int customerId) {
        try {
           
            Accounts accounts = accountsRepository.findByCustomerId(customerId);

            List<Cards> cards = cardsFeignClient.getCardsForCustomer(customerId);

            List<Loan> loans = LoanFeignClient.getLoansForCustomer(customerId);

            List<Insurance> insurances = insuranceFeignClient.getInsuranceForCustomer(customerId);

            CustomerDetails customerDetails = new CustomerDetails();
            ((Object) customerDetails).setAccounts(accounts);
            customerDetails.setCards(cards);
            customerDetails.setLoans(loans);
            customerDetails.setInsurances(insurances);

            return ResponseEntity.ok(customerDetails);
        } catch (Exception e) {
            logger.error("Error retrieving customer details.", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/configProps")
    public ConfigProp getPropertyDetails() {
 
        return new ConfigProp(
            accountsConfig.getMsg(),
            accountsConfig.getBuildVersion(),
            accountsConfig.getMailDetails(),
            accountsConfig.getActiveBranches()
        );
    }
    
    
    @PostMapping("/profile")
    public CustomerDetails getCustomerDetails(
            @RequestHeader("correlation-id") String correlationId,
            @RequestBody Customers customer) {
        logger.debug("getCustomerDetails is starting to execute");
        
        int customerId = customer.getCustomerId();
        
        Accounts accounts = accountsRepository.findByCustomerId(customerId);
        
        List<Cards> cards = cardsFeignClient.getcardsDetails(correlationId, customerId);

        List<Loan> loans = loanFeignClient.getLoansForCustomer(customerId);

        List<Insurance> insurances = insuranceFeignClient.getInsuranceForCustomer(customerId);
   
        CustomerDetails customerDetails = new CustomerDetails();
        customerDetails.setAccounts(accounts);
        customerDetails.setCards(cards);
        customerDetails.setLoan(loan);
        customerDetails.setInsurance(insurances);

        logger.debug("getCustomerDetails has finished execution");
        return customerDetails;
    }
}

