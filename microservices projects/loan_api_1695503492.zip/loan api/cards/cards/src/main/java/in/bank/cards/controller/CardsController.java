package in.bank.cards.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import in.bank.cards.models.Cards;
import in.bank.cards.repository.CardsRepository;

import java.util.List;

@RestController
@RequestMapping("/cards")
public class CardsController {

    @Autowired
    private CardsRepository cardsRepository;

    @GetMapping("/{customerId}")
    public List<Cards> getCardsForCustomer(@PathVariable int customerId) {
        return CardsRepository.findByCustomerId(customerId);
    }

    @PostMapping
    public Cards createCard(@RequestBody Cards card) {
        return cardsRepository.save(card);
    }
}
