package in.bank.cards.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import in.bank.cards.models.Cards;
public interface CardsRepository extends JpaRepository<Cards, Long> {
    static List<Cards> findByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
}