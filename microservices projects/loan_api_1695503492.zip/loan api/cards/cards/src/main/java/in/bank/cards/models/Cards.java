package in.bank.cards.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Cards {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "customer_id")
    private int customerId;
    
    @Column(name = "card_number")
    private String cardNumber;
    
    @Column(name = "card_type")
    private String cardType;
    
    @Column(name = "card_holder_name")
    private String cardHolderName;
    
    @Column(name = "expiration_date")
    private String expirationDate;
    
    @Column(name = "cvv")
    private String cvv;
    
    @Column(name = "credit_limit")
    private double creditLimit;
    
    @Column(name = "available_balance")
    private double availableBalance;
    
}

