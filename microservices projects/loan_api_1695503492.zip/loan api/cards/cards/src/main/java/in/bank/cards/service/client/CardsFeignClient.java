package in.bank.cards.service.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import in.bank.cards.models.Cards;
@FeignClient(name = "cards-service", url = "http://cards-service-url") 
public interface CardsFeignClient {

    @GetMapping("/cards/{customerId}")
    List<Cards> getCardsForCustomer(@PathVariable("customerId") int customerId);

    @GetMapping("/cards/{customerId}/{cardId}")
    Cards getCardDetails(@PathVariable("customerId") int customerId, @PathVariable("cardId") Long cardId);
}