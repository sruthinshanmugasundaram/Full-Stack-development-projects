DROP TABLE IF EXISTS Cards;
CREATE TABLE Cards (
    id int PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    card_number VARCHAR(255) NOT NULL,
    card_type VARCHAR(255),
    card_holder_name VARCHAR(255) NOT NULL,
    expiration_date VARCHAR(10) NOT NULL,
    cvv VARCHAR(3) NOT NULL,
    credit_limit DOUBLE NOT NULL,
    available_balance DOUBLE NOT NULL
);


INSERT INTO cards (customer_id, card_number, card_holder_name, expiration_date, cvv, credit_limit, available_balance)
VALUES(1, '1234567890123456', 'John Doe', '12/25', '123', 5000.00, 2500.00),
    (2, '9876543210987654', 'Jane Smith', '11/24', '456', 7500.00, 4000.00),
    (3, '5555666677778888', 'Bob Johnson', '09/23', '789', 10000.00, 8000.00);
