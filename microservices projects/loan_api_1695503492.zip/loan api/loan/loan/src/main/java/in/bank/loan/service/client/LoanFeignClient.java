package in.bank.loan.service.client;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import in.bank.loan.models.CustomerDetails;
import in.bank.loan.models.Loan;
@FeignClient("loan")
public interface LoanFeignClient {
    
    @RequestMapping(method = RequestMethod.POST, value = "/loan", consumes = "application/json")
    List<Loan> getLoanDetails(@RequestBody CustomerDetails customer);

	List<Loan> getLoanDetails(String correlation, in.bank.loan.models.Loan customer);
}
