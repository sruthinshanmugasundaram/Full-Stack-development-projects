package in.bank.loan.controller;

import lombok.Data;

@Data
public class LoanRequest {
	private int customerId;

}
