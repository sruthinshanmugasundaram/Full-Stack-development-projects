package in.bank.loan.models;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerDetails {
	
	private Loan loan1;
	private List<Loan> loan;
	
	private String customerId;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

	public void setLoan(Loan loan2) {
		// TODO Auto-generated method stub
		
	}
}
