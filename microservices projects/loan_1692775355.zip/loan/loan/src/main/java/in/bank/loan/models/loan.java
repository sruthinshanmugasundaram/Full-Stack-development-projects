package in.bank.loan.models;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
@Entity
public class loan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "loan_Amount")
    private double loanAmount;
    
    @Column(name = "interest_Rate")
    private double interestRate;
    
    @Column(name = "loan_duration")
    private int loanDuration;

    @ManyToOne
    private loanApplication applicant;

}

