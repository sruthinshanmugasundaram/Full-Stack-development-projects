package in.bank.loan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import in.bank.loan.models.*;
import in.bank.loan.repository.LoanRepository;
@RestController
public class LoanController {
	@Autowired
	private LoanRepository loanRepository;
	@PostMapping("/accounts")
	public Accounts getAccountDetails(@RequestBody Customer customer) {
		Accounts loan = loanRepository.findByCustomerId(customer.getcustomerId());
		return loan;
	}

}
