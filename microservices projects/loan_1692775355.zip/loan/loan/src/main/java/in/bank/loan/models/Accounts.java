package in.bank.loan.models;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter 
@Setter 
@ToString
public class Accounts {
     @Column(name = "customer_id")
     private int customerID;
     
     @Column(name = "account_number")
     private String accountNumber;
     
     @Column(name = "account_type")
     private String accountType;
     
     @Column(name = "branch")
     private String branch;
     
     @Column(name = "created_date")
     private LocalDate createdDate;
     
}
