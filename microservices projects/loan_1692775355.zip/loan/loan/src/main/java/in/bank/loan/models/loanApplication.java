package in.bank.loan.models;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class loanApplication {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "name")
    private String name;
    
    @Column(name = "mobile_number")
    private String mobileNumber;
    
    @Column(name = "address")
    private String address;
    
    @Column(name = "loan_amount")
    private double LoanAmount;
    
    @Column(name = "employmentDetails")
    private String employmentDetails;

    // Constructors, getters, setters
}

