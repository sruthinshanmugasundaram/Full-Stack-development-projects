package in.bank.loan.models;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "customer_id")
    private int customerId;
	
     @Column(name = "name")
     private String name;
     
     @Column(name = "mobile_number")
     private String mobileNumber;
     
     @Column(name = "email_id")
     private String emailID;
     
     @Column(name = "created_date")
     private LocalDate createdDate;

	public int getCustomerId() {
		
		return 0;
	}

	public int getcustomerId() {
		
		return 0;
	}
     
}
