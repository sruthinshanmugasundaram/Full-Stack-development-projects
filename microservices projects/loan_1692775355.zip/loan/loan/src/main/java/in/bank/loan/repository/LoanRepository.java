package in.bank.loan.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import in.bank.loan.models.*;
@Repository

public interface LoanRepository extends CrudRepository<Accounts, Long>{
	Accounts findByCustomerId(int customerID);

}
