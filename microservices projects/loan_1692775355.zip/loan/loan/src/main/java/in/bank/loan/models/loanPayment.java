package in.bank.loan.models;

import java.sql.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class loanPayment {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name = "customer_id")
	 private Long customerID;

	 @Column(name = "payment_amount")
	 private double paymentAmount;
	 
	 @Column(name = "payment_date")
	 private Date paymentDate;

     @ManyToOne
 
     private loan loan;

}
