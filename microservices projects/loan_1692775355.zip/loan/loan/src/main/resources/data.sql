Drop table IF EXISTS Accounts;
Drop table IF EXISTS Customer
Drop table IF EXISTS loan;
Drop table IF EXISTS loanApplication;
Drop table IF EXISTS interestRate;
Drop table IF EXISTS loanPayment;

CREATE TABLE 'Customer'{
'customer_id' int AUTO_INCREMENT PRIMARY KEY,
'name' varchar(50) NOT NULL,
'mobile_number' varchar(13) NOT NULL,
'email_id' varchar(100) NOT NULL,
'created_date' date DEFAULT NULL
};


CREATE TABLE 'Accounts'{
'customer_id' int NOT NULL,
'account_number' int AUTO_INCREMENT PRIMARY KEY,
'account_type' varchar(100) NOT NULL,
'branch' varchar(100) NOT NULL,
'created_date' date DEFAULT NULL
};

CREATE TABLE 'loan'{
'customer_id' int NOT NULL,
'loan_Amount' int NOT NULL,
'interest_Rate' varchar(3) NOT NULL,
'loan_duration' int NOT NULL,
};


CREATE TABLE 'loanApplication'{
'customer_id' int NOT NULL,
'name' varchar(100) not null,
'mobile_number' int(13) NOT NULL,
'address' varchar(200) NOT NULL,
'loan_amount' INT NOT NULL,
'employmentDetails' varchar(200) DEFAULT NULL 
};


CREATE TABLE 'loanPayment'{
'customer_id' int NOT NULL,
'payment_amount' int NOT NULL,
'payment_date' date DEFAULT NULL
};


CREATE TABLE 'interestRate'{
'customer_id' int NOT NULL,
'loan_type' varchar(100) NOT NULL,
'interest_rate' varchar(3) NOT NULL,
'min_loan_duration' int NOT NULL,
'max_loan_duration' int NOT NULL
};

INSERT INTO 'Customer'('name','mobile_number','email_id','created_date')VALUES ('sruthin1','9876543456','sdfghgfdsd@gmail.com',CURDATE());
INSERT INTO 'Customer'('name','mobile_number','email_id','created_date')VALUES ('sruthin2','5678654345','ertyjcvbvbbn@gmail.com',CURDATE());
INSERT INTO 'Customer'('name','mobile_number','email_id','created_date')VALUES ('sruthin3','3234565679','sjhfghjujfdsd@gmail.com',CURDATE());

INSERT INTO 'Accounts'('customer_id','account_type','branch','created_date')VALUES (1,'savings','chennai',CURDATE());
INSERT INTO 'Accounts'('customer_id','account_type','branch','created_date')VALUES (2,'current','delhi',CURDATE());
INSERT INTO 'Accounts'('customer_id','account_type','branch','created_date')VALUES (3,'savings','bombay',CURDATE());

INSERT INTO 'loan'('customer_id','loan_Amount','interest_Rate','loan_duration')VALUES (1,100000,'0.14',24);
INSERT INTO 'loan'('customer_id','loan_Amount','interest_Rate','loan_duration')VALUES (2,200000,'0.13',36);
INSERT INTO 'loan'('customer_id','loan_Amount','interest_Rate','loan_duration')VALUES (3,1000000,'0.15',18);

INSERT INTO 'loanApplication'('customer_id','name','mobile_number','address','loan_amount','employmentDetails')VALUES (1,'sruthin1',7545676543,'1st main road,california,america',1000000,'234543-santhosh');
INSERT INTO 'loanApplication'('customer_id','name','mobile_number','address','loan_amount','employmentDetails')VALUES (2,'sruthin2',8765456789,'1st main road,stockholm,sweden',100000,'234543-arun');
INSERT INTO 'loanApplication'('customer_id','name','mobile_number','address','loan_amount','employmentDetails')VALUES (3,'sruthin3',7654456789,'1st main road,paris,rome',500000,'234567-sathes');

INSERT INTO 'loanPayment'('customer_id','payment_amount','payment_date')VALUES (1,100000,CURDATE());
INSERT INTO 'loanPayment'('customer_id','payment_amount','payment_date')VALUES (2,4500000,CURDATE());
INSERT INTO 'loanPayment'('customer_id','payment_amount','payment_date')VALUES (3,2000000,CURDATE());

INSERT INTO 'interestRate'('customer_id','loan_type','interest_rate','min_loan_duration','max_loan_duration')VALUES (1,'vehicle','0.14',6,24);
INSERT INTO 'interestRate'('customer_id','loan_type','interest_rate','min_loan_duration','max_loan_duration')VALUES (2,'house','0.13',6,36);
INSERT INTO 'interestRate'('customer_id','loan_type','interest_rate','min_loan_duration','max_loan_duration')VALUES (3,'bussiness','0.12',6,30);