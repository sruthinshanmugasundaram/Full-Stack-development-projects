package com.example.dateAndTime;

import java.text.SimpleDateFormat;
import java.util.Date;


public class dateAndTime {


	
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");
   
    public static void main(String[] args) {
            
        Date date = new Date();
       
        System.out.println(sdf.format(date));       
    }
}

