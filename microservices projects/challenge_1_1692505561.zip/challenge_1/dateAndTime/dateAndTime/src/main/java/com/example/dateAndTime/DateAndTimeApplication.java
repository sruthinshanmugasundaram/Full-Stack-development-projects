package com.example.dateAndTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DateAndTimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DateAndTimeApplication.class, args);
	}

}
