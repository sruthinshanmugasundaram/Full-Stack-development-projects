package com.example.dateAndTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DateAndTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
