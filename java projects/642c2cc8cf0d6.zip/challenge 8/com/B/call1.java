package com.B.firstcall.call1;
import java.util.Scanner;

import com.A.integerreverse.*;
public class firstcall{
	public static int call1 {
		Scanner sc = new scanner(system.in);
		System.out.println("enter the number:");
		int j = sc.nextInt();
		int v = reverse(j);
		return v;
	}
}
	
	
