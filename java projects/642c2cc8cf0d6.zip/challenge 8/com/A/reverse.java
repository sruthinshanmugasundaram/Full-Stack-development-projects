package com.A.integerreverse;
import java.lang.*;
import java.util.*;
public class integerreverse{
	public static int reverse(int n) {
		String s = Integer.toString(n);
		StringBuilder a = new StringBuilder();
		a.append(s);
		a.reverse();
		int b = string.tointeger(a);
		return b;
	}
}
