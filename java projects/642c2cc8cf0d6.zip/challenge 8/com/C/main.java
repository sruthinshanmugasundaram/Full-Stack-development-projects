import com.B.firstcall.*;
public class main {
	public static void main(string[] args) {
		System.out.println(call1());
	}

}
