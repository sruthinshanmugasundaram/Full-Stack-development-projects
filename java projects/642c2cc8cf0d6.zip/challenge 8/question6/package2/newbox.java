import com.question6.package1.*;

import java.util.Scanner;
import java.util.scanner;
public class newbox {
	public static void main(string[] args) {
		Scanner sc = new scanner(System.in);
		system.out.println("enter the dimension of box :");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		System.out.println(area(a,b,c));
	}
}
