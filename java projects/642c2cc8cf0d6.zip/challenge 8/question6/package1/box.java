package com.question6.package1;
public class box {
	 int l;
	 int w;
	 int b;
	    
     box(int l,int w,int b){
		 length = l;
	     breadth = w;
	     height = b;
	 }
}

public int area(int l,int w,int b) {
	int a = l * w * b;
	return a;
}

public class box_dimension{
	public static void main(String[] args) {
		1
        box b1 = new box(){		             
			l = 5;
            w = 8;
	        b = 3;
	    }
		system.out.println("length:"+b1.l+"width:"+b1.w+"breadth:"+b1.b);
        System.out.println("area:"+b1.area(l,w.b));
		
        box b2 = new box(){
		    l = 7;
		    w = 4;
		    b = 9;
		}
	    system.out.println("length:"+b2.l+"width:"+b2.w+"breadth:"+b2.b);
	    System.out.println("area:"+b2.area(l,w.b));
	             
		box b3 = new box(){
		    l = 9;
		    w = 2;
		    b = 7;
        }
		system.out.println("length:"+b3.l+"width:"+b3.w+"breadth:"+b3.b);
		System.out.println("area:"+b3.area(l,w.b));
     }
}
