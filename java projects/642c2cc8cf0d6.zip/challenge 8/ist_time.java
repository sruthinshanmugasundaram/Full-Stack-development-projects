import java.time.*;
import java.time.format.DateTimeFormatter;

public class ist_time {
    public static void main(String[] args) {
        LocalTime gmt = LocalTime.now(ZoneId.of("GMT"));
        LocalTime ist = gmt.atZone(ZoneId.of("Asia/Kolkata")).toLocalTime();
        String istDateTime = ist.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        System.out.println(istDateTime);
    }
}
