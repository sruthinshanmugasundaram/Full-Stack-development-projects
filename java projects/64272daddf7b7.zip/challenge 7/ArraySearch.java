public class ArraySearch {
    public static boolean findElements(int[] arr, int target) throws Exception {
       for (int i = 0; i < arr.length; i++) {
          if (arr[i] == target) {
             return true;
          }
       }
       throw new Exception("id is not valid");
    }
 
    public static void main(String[] args) {
       int[] arr1 = { 1, 23, 56, 7, 8, 8, 7};
       int target1 = 108;
 
       int[] arr2 = { 34, 4, 33, 3, 43, 2, 32, 56 };
       int target2 = 43;
 
       try {
          boolean isTargetValid1 = findElements(arr1, target1);
          System.out.println("id is valid");
 
          boolean isTargetValid2 = findElements(arr2, target2);
          System.out.println("id is valid");
       } catch (Exception e) {
          System.out.println(e.printStackTrace());
       }
    }
 }
 