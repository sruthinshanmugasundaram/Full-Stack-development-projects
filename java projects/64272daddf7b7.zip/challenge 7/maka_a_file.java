import java.io.file;
import java.io.ioexception;

public class make_a_file{
    public static void main(String[] args) {
        file File = new file("Source.txt");
       try(bufferwriter bw = new bufferwriter(new filewriter(File,true))){
        bw.write("hello my name is sruthin");
        bw.nextline();
        bw.write("i pursuing my fds course in skill lync");
       } 
       catch(ioexception e){
        e.printstacktrace();
       }
       try{
        scanner sc = new scanner(File);
        string contents;
        while(sc.hasnext()){
            contents = sc.nextline();
            file File2 = new file("Target.txt");
            try(bufferwriter bw = new bufferwriter(new filewriter(File2,true))){
                bw.write(contents);
                bw.flush();
            }
            catch(filenotfoundexception e){
                e.printstacktrace();
            }
        }
       }
       catch(ioexception e){
        e.printstacktrace();
    }
}