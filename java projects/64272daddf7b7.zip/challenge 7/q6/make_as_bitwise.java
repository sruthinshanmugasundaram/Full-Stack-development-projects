import java.io.fileoutputstream;
import java.io.filenotfoundexception;
import java.io.objectoutputstream;
import java.io.ioexception;
public class logics{
    public static void main(String[] args) {
        members m = new members(1 , "member1");
        try(fileoutputstream file = new fileoutputstream("members_list.txt")){
           objectoutput obj = new objectoutputstream(file);
           obj.writeobject(m);
           obj.flush();
        }
        catch (filenotfoundexception e){
            e.printstacktrace();
        }
        catch(ioexception e){
            e.printstacktrace();
        }
    }
}