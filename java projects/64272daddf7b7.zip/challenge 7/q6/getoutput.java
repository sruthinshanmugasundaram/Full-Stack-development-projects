import java.io.ioexception;
import java.io.fileinputstream;
import java.io.objectinputstream;
public class getoutput{
    public static void main(String[] args) {
       try(objetinputstream objin = new objectinputstream(new fileinputstream("members_list.txt"))){
            members m = (members) in.readobjet();
            system.out.println(m.id+""+m.name);
       }
       catch (ioexception e){
        e.printstacktrace();
       }
       catch (classnotfoundexception e){
        e.printstacktrace();
       }   
    }
}