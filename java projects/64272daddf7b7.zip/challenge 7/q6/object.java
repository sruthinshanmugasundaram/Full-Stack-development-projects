import java.io.serializable;
public class members implements serializable {
    int count;
    string name;
public members(int count, string name){
    super();
    this.count = count;
    this.name = name;
    
}
}
