abstract class bank {
    abstract int getbalance();

}
 
class bankA extends bank{
    private int a = 100;
    public int getbalance(){
        return "Deposited Balance is = $"+a;
    }
}

class bankB extends bank{
    private int a = 150;
    public int getbalance(){
        return "Deposited Balance is = $"+a;
    }
}

class bankC extends bank{
    private int a = 200;
    public int getbalance(){
        return "Deposited Balance is = $"+a;
    }
}

public class main{
public static void main(String[] args) {
    bankA bankA = new bankA();
    bankB bankB = new bankB();
    bankC bankC = new bankC();
    system.out.println(""+bankA.getbalance());
    system.out.println(""+bankB.getbalance());
    system.out.println(""+bankC.getbalance());
}
}