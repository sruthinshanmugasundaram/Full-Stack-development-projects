abstract class marks{
    abstract void getPercentage();
}

class A extends marks{
    private int (a , b , c);
    public A (int a , b , c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    private int sum = a + b + c;
    private int percent = (sum / 300) * 100;
    public void getPercentage(){
        system.out.println(""+percent);
    }
}

class B extends marks{
    private int a ,int b ,int c ,int d;
    public A (int a ,int b ,int c ,int d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    private int sum = a + b + c + d;
    private int percent = (sum / 400) * 100;
    public void getPercentage(){
        system.out.println(""+percent);
    }
}

public class main{
    public static void main(String[] args) {
        A a = new A(70, 50, 100);
        B b = new B(90, 75, 64, 86);
        a.getPercentage();
        b.getPercentage();
    }
}