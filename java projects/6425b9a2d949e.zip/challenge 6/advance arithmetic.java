interface AdvancedArithmetic{
    int divisor_sum(int n)
}

class MyCalculator implements AdvancedArithmetic{
    int divisor_sum(int n){
        int k = n;
        for(int i = 0;i<=n;i++){
            if(n % i == 0){
                k = k + i;
            }
        }
    system.out.println(k);
    }
}

public class main{
    public static void main(String[] args) {
        scanner sc = new scanner(system.in);
        int n = sc.nextint();
        AdvancedArithmetic advancedArithmetic= new AdvancedArithmetic();
        MyCalculator m = new MyCalculator();
        if(n <= 1000){
            advancedArithmetic.divisor_sum(n);
        }
    }
}