package com.banking.details.RBI;
import com.banking.details.*;
public class RBI {
	public double savingsaccount() {
        return a;
    }

    public double getWithdrawalLimit() {
        return ;
    }
}


class SavingsAccount extends RBI {
    private double balance;

    public SavingsAccount(double balance) {
        this.balance = balance;
    }

    @Override
    public double getInterestRate() {
        return ;
    }

    public double calculateSimpleInterest(int years) {
        double rate = getInterestRate();
        double principal = balance;
        double amount = principal * (1 + rate * years);
        double interest = amount - principal;
        return interest;
    }

    public double calculateTotalAmount(int years) {
        double rate = getInterestRate();
        double principal = balance;
        double amount = principal * (1 + rate * years);
        return amount;
    }
}


class CurrentAccount extends RBI {
    private double balance;

    public CurrentAccount(double balance) {
        this.balance = balance;
    }

    @Override
    public double getInterestRate() {
        return ;
    }

    public double calculateCompoundInterest(int years) {
        double rate = getInterestRate();
        double principal = balance;
        int n = 2; 
        double amount = principal * Math.pow(1 + rate/n, n*years);
        double interest = amount - principal;
        return interest;
    }

    public double calculateTotalAmount(int years) {
        double rate = getInterestRate();
        double principal = balance;
        int n = 2; 
        double amount = principal * Math.pow(1 + rate/n, n*years);
        return amount;
    }
}
}
