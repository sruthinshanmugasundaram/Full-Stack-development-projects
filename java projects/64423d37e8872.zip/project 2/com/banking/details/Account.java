package com.banking.details.Account;
import com.banking.details.*;
public class Account {
	public int verification() {
		int a = current.hashCode();
		string j = current.getname();
		int b = j.hashCode();
		@Override  
		public boolean equals(Object obj)   {  
			if (obj == null)   
				return false;  
			if (obj == this)  
				return true;  
			return this.getname() == ((Employee) obj). getname();  
		}  
	}
	public int addingbalance(int e,int f) {
		int balance = e + f;
		return balance();
		
	}
	public int withdraw(int g, int h) {
		int i = g - h;
		try{
			if(i>=2000) {
				System.out.println("withdrawal is completed. available balance : "+i);	
			}
			else(i<=2000){
				system.println("your bank balance is not sufficient for withdraw");
			}
		}catch(InterruptedException g) {
			g.printStackTrace();
		}
			
		}
	}
}
