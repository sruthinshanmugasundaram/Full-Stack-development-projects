package com.banking.details.currentaccount;
import com.banking.details.*;
import java.math.*;
class user{
	final int min = 5000;
	string name;
	string dob;
	string account_type;
	int balance;
}
public class currentaccount extends RBI{
	public void interest(int p,int r,int t) {
		int n=2;
		int A = math.pow(p(1+(r/n)),(n * t) ));
		System.out.println("final amount="+A);
		System.out.println("total amount="+(A-p));
	}
	public stati void main(string[] args) {
		user c = new user;
		c.name = "c";
		c.dob = "12 09 1998";
		c.account_type="current";
		c.balance = 8500;
		
		user d = new user;
		d.name = "d";
		d.dob = "17 01 2002";
		d.account_type="current";
		d.balance = 12000; 
	}
}
