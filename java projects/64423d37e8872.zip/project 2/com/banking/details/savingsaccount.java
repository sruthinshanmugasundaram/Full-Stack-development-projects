package com.banking.details.savingsaccount;
import com.banking.details.*;
class users{
	final int min =2000;
	string name;
	string dob;
	string account_type;
	int balance;
}
public class savingsaccount extends RBI {
	public void interest(int p,int r,int t) {
		int A = p(1+rt);
		System.out.println("final amount="+A);
		System.out.println("total amount="+(A-p));
		
	}
	public static void main(string[] args) {
		user a = new user();
		a.name = "a";
		a.dob = "12 09 1999";
		a.account_type="savings";
		a.balance = 6500;
		
		user b = new user();
		b.name = "b";
		b.dob = "27 05 1996";
		b.account_type="savings";
		b.balance = 10000; 
	}
}
