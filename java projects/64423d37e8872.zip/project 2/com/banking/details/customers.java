package com.banking.details.customers;
import com.banking.details.*;
import java.util.*;
public class customers extends Account {
	system.out.println("welcome to the customers");
	system.out.println("you already had an account: Y/N");
	Scanner sc= new scanner(system.in);
	string choice = sc.nextstring();
	if(choice==Y || y) {
		system.out.println("which bank we want to access SBI / ICICI / PNB / RBI");
		string bank= sc.nextstring();
		system.out.println("what type of account you have? Savings / Current");
		string accounttype = sc.nextstring();
		string 
		if(bank==RBI || rbi ||Rbi ||ICICI || PNB || SBI) {
			typeOfUser=typeOfUser;
			user current= new user();
			system.out.println("Insert name, type of account and date of birth (dd mm yyyy)");
			sc.nextline();
			current.setname(sc.nextline());
			sc.nextline();
			current setaccounttype(sc.nextline());
			sc.nextline();
			current setdob(sc.nextline());
			if(current.verification()==true) {
				System.out.println("your account is opened");
				System.out.println("what do you want deposit / balance enquiry / withdraw ");
				int f = j.getbalance();
				string d = sc.nextstring();
				if(d == deposit || Deposit || DEPOSIT) {
					System.out.println("how much did you want to deposit");
					int e = sc.nextint();
					try {
						int j = (addingbalance(e,f));
						System.out.println("your amount is deposited");
					}check(InterruptedException g){
						System.out.println("your amount is not deposited! it had some errors");
					}
					
				}
				else if(d == balance enquiry || Balance Enquiry || Balance enquiry) {
					system.out.println("your balance is : "+j.getbalance());
					
				}
				else if(d==withdraw || Withdraw || withdrawal) {
					System.out.println("how much did you need for withdrawal: ");
					int g = sc.nextInt();
					withdraw(f,g);
				}
			}
			
		
		}
	}
	
	
}
