class table{
    private object lock = "lock";
    public void printtables(int n){
        synchronized(lock){
            for (int i = 1;i<=10; i++){
                int j = n * i;
                system.out.println("table of"+n+" is "+j);
            } 
            try{
                Thread.sleep(1600);
            }catch(interruptedexception e){
                e.printstacktrace
            }
        } 
    } 
}


public class threads{
    public static void main(String[] args) {
        threads thread = new threads();
        new thread(new runnable()){
            public void run(){
                thread.printtables(5);
            }
        }.start();
        new thread(new runnable()){
            public void run(){
                thread.printtables(7);
            }
        }.start();
        thread.join();
        system.out.println("process is completed");
    } 
}