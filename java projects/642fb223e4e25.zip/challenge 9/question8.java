import java.util.concurrent.*;
import java.util.concurrent.locks.reentrantlock;

public class new_thread implement Runnable{
        @override
        public static void run(){
            lock.lock();
            for(init i = 1;i<=10;i++){
                system.out.println(i+"x"+n+"="+n*i)
                n++;
            }
            lock.unlock();
            countDownLatch.countDown();
        }
    })
}
public class new_thread2 extends thread{
    public static void run(){
        lock.lock();
        for(init i = 11;i<=20;i++){
            system.out.println(i+"x"+n+"="+n*i)
            n++;
        }
        lock.unlock();
    }
    try{
        thread.sleep(2000);
    }catch(InterruptedException e){
        e.printstacktrace(); 
    }
}

public class dead_lock{
    static int n = 1;
    static lock lock = new reentrantlock();
    private CountDownLatch countDownLatch;
    private mine(CountDownLatch countDownLatch){
        super(name);
        this.countDownLatch = countDownLatch;
    }
    public static void main(String[] args) {
        thread new_thread = new thread(){
        thread new_thread2 = new thread(){
        threads thread1 = new threads(new_thread())    
        thread1.start();
        new_thread2.start();
    }
}