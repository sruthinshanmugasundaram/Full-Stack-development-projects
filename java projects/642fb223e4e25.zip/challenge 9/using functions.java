class calling extends Thread {
    private final Object call;
    public calling(Object call) {
        this.call = call;
    }
    public void run() {
        synchronized (call) {
            try {
                System.out.println(Thread.currentThread().getName() + " is waiting");
                call.wait();
                System.out.println(Thread.currentThread().getName() + " has been notified");
            } catch (InterruptedException e) {
                System.out.println("Exception caught: " + e.getMessage());
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Object call = new Object();
        calling t1 = new calling(call);
        calling t2 = new calling(call);
        calling t3 = new calling(call);

        t1.start();
        t2.start();
        t3.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println("Exception caught: " + e.getMessage());
        }

        synchronized (call) {
            call.notifyAll();
        }
    }
}
