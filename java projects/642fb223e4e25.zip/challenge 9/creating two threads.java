class thread1 extends Thread {
    public void run(){
        system.out.println("thread1 name = "+this.getname()+"and thread1 ID = "+this.getid());
    }

}

class thread2 extends Thread{
    public void run(){
        system.out.println("thread2 name = "+this.getname()+"and thread2 ID = "+this.getid());
    }
}

public class threadname_and_id{
    public static void main(String[] args) {
        thread thread1 = new thread("thread 1");
        thread thread2 = new thread("thread 2");
        thread1.start();
        thread2.start();
    }
}