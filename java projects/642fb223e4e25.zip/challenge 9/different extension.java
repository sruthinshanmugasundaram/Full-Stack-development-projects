class first_thread extends Thread {
    public void run(){
        system.out.println("thread 1 is running...");
    }

}

class second_thread implement Runnable{
    public void run(){
        system.out.println("thread 2 is running...");
    }
}

public class threads{
    public static void main(String[] args) {
        threads first_thread = new threads();
        Runnable second_thread = new thread();
        thread second = new thread(second_thread);
        firstst_thread.start();
        second.start();
        second.join();
        system.out.println("process is completed");
    } 
}