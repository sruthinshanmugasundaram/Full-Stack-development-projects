class  person{
    constructor(name, age) {
    this.name = name;
    this.age = age;
    }
    greet() {
    console.log(`Welcome to ${this.name}, ${this.age} is your age`);
    }
    }
    const person1 = new person("sudha", 40);
    const person2 = new person("ram", 25);
    console.log(person1.name); 
    console.log(person2.age);  
    person1.greet();  
    person2.greet();
   