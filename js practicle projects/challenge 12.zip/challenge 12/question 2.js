class person {
    constructor(name) {
    this.name = name;
    }
    speak() {
    console.log(`${this.name} is my name`);
    }
    }
    class male extends person {
    constructor(name, relationship) {
    super(name);
    this.relationship = relationship;
    }
    introduce() {
    console.log(`${this.name} is your ${this.relationship}`);
    }
    }
    const Person1 = new male("ram", "friend");
    Person1.speak();
    Person1.introduce();