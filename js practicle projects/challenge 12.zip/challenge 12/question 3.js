class Person {
    constructor(name, age) {
      this._name = name;
      this._age = age;
    }
    get name() {
      return this._name;
    }
    set name(newName) {
      if (typeof newName === 'string' && newName.length > 0) {
        this._name = newName;
      } else {
        console.log('Name must be a non-empty string');
      }
    }
    get age() {
      return this._age;
    }
    set age(newAge) {
      if (typeof newAge === 'number' && newAge >= 0) {
        this._age = newAge;
      } else {
        console.log('Age must be a non-negative number');
      }
    }
  }
  const person = new Person('ram', 30);
  console.log(`Name: ${person.name}`);
  console.log(`Age: ${person.age}`);
  person.name = 'sharma';
  person.age = 25;
  console.log(`Updated Name: ${person.name}`);
  console.log(`Updated Age: ${person.age}`);
  