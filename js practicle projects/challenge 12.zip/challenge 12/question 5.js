class Person {
    constructor(name) {
      this.name = name;
    }
    greet() {
      console.log(`Hello, my name is ${this.name}`);
    }
    static defaultName = "Guest";
    static createWithName(name) {
      return new Person(name || this.defaultName);
    }
  } 
   const person1 = new Person("sharma");
  person1.greet(); 
  const person2 = Person.createWithName();
  person2.greet(); 
  