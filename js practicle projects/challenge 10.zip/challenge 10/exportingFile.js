//question 1
const invitation = (name) => {console.log("this is my invitation to invite you for my wedding, mr "+name);};
const foodMenu = () => {console.log("idle, doosa, noodles, briyani");};
module.exports = {
invitation,
foodMenu
};

//question 2 
class MyClass {
    constructor(name){
      this.name = this.name;
    };
    sayHello = () => {
      console.log(`Hello, my name is ${this.name}`);
    };
  }
  module.exports = MyClass;


  
//question 3
const myObject = {
    name: "sruthin s",
    age: 24,
    location: "chennai",
  };
  module.exports = myObject;
  