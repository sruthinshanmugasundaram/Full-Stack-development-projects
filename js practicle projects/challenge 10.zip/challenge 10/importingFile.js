//question 1
const math = require('./exportingFile');
const a = "sruthin s";
exportingFile.invitation(a);
exportingFile.foodMenu(); 


//question 2
const exportingClass = require('./exportingFile');
const mynewClass = new exportingClass("sruthin s");
mynewClass.sayHello();


//question 3
import myObject from './exportingFile';
console.log(`Name: ${myObject.name}`);
console.log(`Age: ${myObject.age}`);
console.log(`Location: ${myObject.location}`);
  

