function createCounter() {
    let count = 0;
    function increment() {
      count++;
      console.log(count);
    }
    return increment;
  }
  const counter1 = createCounter();
  const counter2 = createCounter();
  counter1();
  counter1(); 
  counter2(); 
  counter2();
  