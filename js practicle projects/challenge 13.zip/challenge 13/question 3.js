function counters() {
    const counter = { 
      count: 0, 
      increment: () => {
        counter.count++;
        console.log(counter.count);
      },
    };
    return counter.increment;
  }
  const incrementCounter = counters(); 
  incrementCounter();
  incrementCounter(); 