function passingParameter(greeting){
    return function(name){console.log(`${greeting},${name}`);}
}
const reference1 = passingParameter("helllo");
const reference2 = passingParameter("hi");
reference1("sruthin");
reference2("ram");