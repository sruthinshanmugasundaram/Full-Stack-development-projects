function Animal(name) {
    this.name = name;
  } 
  Animal.prototype.speak = function() {
    console.log(`${this.name} says hello!`);
  }
  const myAnimal = new Animal("fido"); 
  myAnimal.speak = function() {
    console.log(`${this.name} makes a sound.`);
  }
  myAnimal.speak();