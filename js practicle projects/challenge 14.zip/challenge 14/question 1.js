const personPrototype = {
    constructor(name){
    this.name = name;},
    greet: function() {
      console.log(`Hello, my name is ${this.name}`);
    },
  };
  const person = Object.create(personPrototype);
  person.name = "sruthin";
  person.greet(); 