
function personPrototype(name) {
    this.name = name;
    }
    personPrototype.prototype.greet = function() {
    console.log(`welcome to ${this.name},have a nice day`);
    };
    const person = new personPrototype("Fido");
    person.greet()