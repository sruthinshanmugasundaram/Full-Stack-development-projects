-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2023 at 07:42 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-commerence`
--

-- --------------------------------------------------------

--
-- Table structure for table `couponcodes`
--

CREATE TABLE `couponcodes` (
  `coupon_id` int(11) NOT NULL,
  `discount_rule` varchar(255) NOT NULL,
  `percentage` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `couponcodes`
--

INSERT INTO `couponcodes` (`coupon_id`, `discount_rule`, `percentage`) VALUES
(1, 'SUMMER50', 50.00),
(2, 'SALE25', 25.00),
(3, 'WELCOME10', 10.00);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `delivery_addresses` text DEFAULT NULL,
  `contacts` varchar(255) DEFAULT NULL,
  `current_orders` text DEFAULT NULL,
  `previous_orders` text DEFAULT NULL,
  `payment_info_saved` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `gender`, `dob`, `city`, `password`, `name`, `email`, `delivery_addresses`, `contacts`, `current_orders`, `previous_orders`, `payment_info_saved`) VALUES
(1, 'male', '1990-05-15', 'New York', 'customer123', 'John Doe', 'john@example.com', 'Address 1, Address 2', '1234567890', '2,3', '1,4', 'Credit Card XXXX-XXXX-XXXX-1234'),
(2, 'female', '1985-08-20', 'Los Angeles', 'customer456', 'Jane Smith', 'jane@example.com', 'Address 3', '9876543210', '1', '2,3,4', 'PayPal jane@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `status` enum('cancelled','completed','ordered','packed','shipped','delivered') NOT NULL,
  `delivery_expectation` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `order_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `status`, `delivery_expectation`, `delivery_date`, `order_date`) VALUES
(1, 1, 'ordered', '2023-08-01', '2023-08-05', '2023-08-01'),
(2, 2, 'packed', '2023-08-03', '2023-08-07', '2023-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `productreviews`
--

CREATE TABLE `productreviews` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `review_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productreviews`
--

INSERT INTO `productreviews` (`review_id`, `product_id`, `customer_id`, `rating`, `review_text`) VALUES
(1, 3, 1, 4, 'Great product! Highly recommended.'),
(2, 5, 2, 5, 'Excellent quality and fast delivery.');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(50) DEFAULT NULL,
  `seller_id` int(11) NOT NULL,
  `sizes_available` varchar(255) DEFAULT NULL,
  `quantity_available` int(11) DEFAULT NULL,
  `cost` decimal(10,2) NOT NULL,
  `current_discount` decimal(5,2) NOT NULL,
  `place_of_origin` varchar(100) DEFAULT NULL,
  `calculations` text DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT NULL,
  `popularity_index` int(11) DEFAULT NULL,
  `avg_ratings` decimal(3,2) DEFAULT NULL,
  `total_ratings` int(11) DEFAULT NULL,
  `reviews_for_ratings` int(11) DEFAULT NULL,
  `review_country` varchar(50) DEFAULT NULL,
  `is_on_sale` tinyint(1) DEFAULT NULL,
  `categories` varchar(255) DEFAULT NULL,
  `brands` varchar(255) DEFAULT NULL,
  `images` text DEFAULT NULL,
  `questions_with_answers` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `related_products_ids` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `color`, `seller_id`, `sizes_available`, `quantity_available`, `cost`, `current_discount`, `place_of_origin`, `calculations`, `is_featured`, `popularity_index`, `avg_ratings`, `total_ratings`, `reviews_for_ratings`, `review_country`, `is_on_sale`, `categories`, `brands`, `images`, `questions_with_answers`, `description`, `tags`, `related_products_ids`) VALUES
(1, 'Product 1', 'Red', 1, 'S,M,L', 50, 49.99, 0.00, 'USA', '885', 1, 100, 4.50, 50, 30, 'USA', 1, 'Electronics', 'BrandA', 'image1.jpg', 'Q1: How is the battery life? A1: The battery lasts for up to 12 hours.', 'Description for Product 1', 'tag1, tag2', '2,5,7'),
(2, 'Product 2', 'Blue', 2, 'M,L,XL', 30, 39.99, 10.00, 'China', '3456', 0, 80, 3.80, 40, 20, 'Canada', 1, 'Clothing', 'BrandB', 'image2.jpg', 'Q1: Is it machine washable? A1: Yes, it can be machine washed.', 'Description for Product 2', 'tag2, tag3', '1,4,6'),
(3, 'Product 1', 'Red', 1, 'S,M,L', 50, 49.99, 0.00, 'USA', '5676', 1, 100, 4.50, 50, 30, 'USA', 1, 'Electronics', 'BrandA', 'image1.jpg', 'Q1: How is the battery life? A1: The battery lasts for up to 12 hours.', 'Description for Product 1', 'tag1, tag2', '2,5,7'),
(4, 'Product 2', 'Blue', 2, 'M,L,XL', 30, 39.99, 10.00, 'China', '679', 0, 80, 3.80, 40, 20, 'Canada', 1, 'Clothing', 'BrandB', 'image2.jpg', 'Q1: Is it machine washable? A1: Yes, it can be machine washed.', 'Description for Product 2', 'tag2, tag3', '1,4,6');

-- --------------------------------------------------------

--
-- Table structure for table `replacements`
--

CREATE TABLE `replacements` (
  `replacement_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `status` enum('requested','approved','rejected') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `replacements`
--

INSERT INTO `replacements` (`replacement_id`, `order_id`, `status`) VALUES
(1, 1, 'requested'),
(2, 2, 'approved'),
(3, 1, 'rejected');

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `seller_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile_no` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `categories_of_products_provided` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`seller_id`, `name`, `mobile_no`, `password`, `categories_of_products_provided`) VALUES
(1, 'Seller A', '9876543211', 'seller123', 'Electronics, Clothing'),
(2, 'Seller B', '9876545678', 'seller98765', 'Toys, Fruits');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `wishlist_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`wishlist_id`, `customer_id`, `product_id`) VALUES
(1, 1, 3),
(2, 2, 5),
(3, 2, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `couponcodes`
--
ALTER TABLE `couponcodes`
  ADD PRIMARY KEY (`coupon_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `productreviews`
--
ALTER TABLE `productreviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `replacements`
--
ALTER TABLE `replacements`
  ADD PRIMARY KEY (`replacement_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`seller_id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`wishlist_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `couponcodes`
--
ALTER TABLE `couponcodes`
  MODIFY `coupon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `productreviews`
--
ALTER TABLE `productreviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `replacements`
--
ALTER TABLE `replacements`
  MODIFY `replacement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sellers`
--
ALTER TABLE `sellers`
  MODIFY `seller_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `productreviews`
--
ALTER TABLE `productreviews`
  ADD CONSTRAINT `productreviews_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`);

--
-- Constraints for table `replacements`
--
ALTER TABLE `replacements`
  ADD CONSTRAINT `replacements_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
