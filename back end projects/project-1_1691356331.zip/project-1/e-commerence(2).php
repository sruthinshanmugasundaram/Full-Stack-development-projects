<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `e-commerence`
 */

/* `e-commerence`.`couponcodes` */
$couponcodes = array(
  array('coupon_id' => '1','discount_rule' => 'SUMMER50','percentage' => '50.00'),
  array('coupon_id' => '2','discount_rule' => 'SALE25','percentage' => '25.00'),
  array('coupon_id' => '3','discount_rule' => 'WELCOME10','percentage' => '10.00')
);

/* `e-commerence`.`customers` */
$customers = array(
  array('customer_id' => '1','gender' => 'male','dob' => '1990-05-15','city' => 'New York','password' => 'customer123','name' => 'John Doe','email' => 'john@example.com','delivery_addresses' => 'Address 1, Address 2','contacts' => '1234567890','current_orders' => '2,3','previous_orders' => '1,4','payment_info_saved' => 'Credit Card XXXX-XXXX-XXXX-1234'),
  array('customer_id' => '2','gender' => 'female','dob' => '1985-08-20','city' => 'Los Angeles','password' => 'customer456','name' => 'Jane Smith','email' => 'jane@example.com','delivery_addresses' => 'Address 3','contacts' => '9876543210','current_orders' => '1','previous_orders' => '2,3,4','payment_info_saved' => 'PayPal jane@example.com')
);

/* `e-commerence`.`orders` */
$orders = array(
  array('order_id' => '1','customer_id' => '1','status' => 'ordered','delivery_expectation' => '2023-08-01','delivery_date' => '2023-08-05','order_date' => '2023-08-01'),
  array('order_id' => '2','customer_id' => '2','status' => 'packed','delivery_expectation' => '2023-08-03','delivery_date' => '2023-08-07','order_date' => '2023-08-02')
);

/* `e-commerence`.`productreviews` */
$productreviews = array(
  array('review_id' => '1','product_id' => '3','customer_id' => '1','rating' => '4','review_text' => 'Great product! Highly recommended.'),
  array('review_id' => '2','product_id' => '5','customer_id' => '2','rating' => '5','review_text' => 'Excellent quality and fast delivery.')
);

/* `e-commerence`.`products` */
$products = array(
  array('product_id' => '1','name' => 'Product 1','color' => 'Red','seller_id' => '1','sizes_available' => 'S,M,L','quantity_available' => '50','cost' => '49.99','current_discount' => '0.00','place_of_origin' => 'USA','calculations' => '885','is_featured' => '1','popularity_index' => '100','avg_ratings' => '4.50','total_ratings' => '50','reviews_for_ratings' => '30','review_country' => 'USA','is_on_sale' => '1','categories' => 'Electronics','brands' => 'BrandA','images' => 'image1.jpg','questions_with_answers' => 'Q1: How is the battery life? A1: The battery lasts for up to 12 hours.','description' => 'Description for Product 1','tags' => 'tag1, tag2','related_products_ids' => '2,5,7'),
  array('product_id' => '2','name' => 'Product 2','color' => 'Blue','seller_id' => '2','sizes_available' => 'M,L,XL','quantity_available' => '30','cost' => '39.99','current_discount' => '10.00','place_of_origin' => 'China','calculations' => '3456','is_featured' => '0','popularity_index' => '80','avg_ratings' => '3.80','total_ratings' => '40','reviews_for_ratings' => '20','review_country' => 'Canada','is_on_sale' => '1','categories' => 'Clothing','brands' => 'BrandB','images' => 'image2.jpg','questions_with_answers' => 'Q1: Is it machine washable? A1: Yes, it can be machine washed.','description' => 'Description for Product 2','tags' => 'tag2, tag3','related_products_ids' => '1,4,6'),
  array('product_id' => '3','name' => 'Product 1','color' => 'Red','seller_id' => '1','sizes_available' => 'S,M,L','quantity_available' => '50','cost' => '49.99','current_discount' => '0.00','place_of_origin' => 'USA','calculations' => '5676','is_featured' => '1','popularity_index' => '100','avg_ratings' => '4.50','total_ratings' => '50','reviews_for_ratings' => '30','review_country' => 'USA','is_on_sale' => '1','categories' => 'Electronics','brands' => 'BrandA','images' => 'image1.jpg','questions_with_answers' => 'Q1: How is the battery life? A1: The battery lasts for up to 12 hours.','description' => 'Description for Product 1','tags' => 'tag1, tag2','related_products_ids' => '2,5,7'),
  array('product_id' => '4','name' => 'Product 2','color' => 'Blue','seller_id' => '2','sizes_available' => 'M,L,XL','quantity_available' => '30','cost' => '39.99','current_discount' => '10.00','place_of_origin' => 'China','calculations' => '679','is_featured' => '0','popularity_index' => '80','avg_ratings' => '3.80','total_ratings' => '40','reviews_for_ratings' => '20','review_country' => 'Canada','is_on_sale' => '1','categories' => 'Clothing','brands' => 'BrandB','images' => 'image2.jpg','questions_with_answers' => 'Q1: Is it machine washable? A1: Yes, it can be machine washed.','description' => 'Description for Product 2','tags' => 'tag2, tag3','related_products_ids' => '1,4,6')
);

/* `e-commerence`.`replacements` */
$replacements = array(
  array('replacement_id' => '1','order_id' => '1','status' => 'requested'),
  array('replacement_id' => '2','order_id' => '2','status' => 'approved'),
  array('replacement_id' => '3','order_id' => '1','status' => 'rejected')
);

/* `e-commerence`.`sellers` */
$sellers = array(
  array('seller_id' => '1','name' => 'Seller A','mobile_no' => '9876543211','password' => 'seller123','categories_of_products_provided' => 'Electronics, Clothing'),
  array('seller_id' => '2','name' => 'Seller B','mobile_no' => '9876545678','password' => 'seller98765','categories_of_products_provided' => 'Toys, Fruits')
);

/* `e-commerence`.`wishlist` */
$wishlist = array(
  array('wishlist_id' => '1','customer_id' => '1','product_id' => '3'),
  array('wishlist_id' => '2','customer_id' => '2','product_id' => '5'),
  array('wishlist_id' => '3','customer_id' => '2','product_id' => '7')
);
