<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `store_database`
 */

/* `store_database`.`customer` */
$customer = array(
  array('customer_id' => '3002','cust_name' => 'Nick Rimando','city' => 'New York','grade' => '100','salesman_id' => '5001'),
  array('customer_id' => '3007','cust_name' => 'Brad Davis','city' => 'New York','grade' => '200','salesman_id' => '5001'),
  array('customer_id' => '3005','cust_name' => 'Graham Zusi','city' => 'California','grade' => '200','salesman_id' => '5002'),
  array('customer_id' => '3008','cust_name' => 'Julian Green','city' => 'London','grade' => '300','salesman_id' => '5002'),
  array('customer_id' => '3004','cust_name' => 'Fabian Johnson','city' => 'Paris','grade' => '300','salesman_id' => '5006'),
  array('customer_id' => '3009','cust_name' => 'Geoff Cameron','city' => 'Berlin','grade' => '100','salesman_id' => '5003'),
  array('customer_id' => '3003','cust_name' => 'Jozy Altidor','city' => 'Moscow','grade' => '200','salesman_id' => '5007')
);

/* `store_database`.`orders` */
$orders = array(
  array('ord_no' => '70001','purch_amt' => '150.5','ord_date' => '2012-10-05','customer_id' => '3005','salesman_id' => '5002'),
  array('ord_no' => '70009','purch_amt' => '270.65','ord_date' => '2012-09-10','customer_id' => '3001','salesman_id' => '5005'),
  array('ord_no' => '70002','purch_amt' => '65.26','ord_date' => '2012-10-05','customer_id' => '3002','salesman_id' => '5001'),
  array('ord_no' => '70004','purch_amt' => '110.5','ord_date' => '2012-08-17','customer_id' => '3009','salesman_id' => '5003'),
  array('ord_no' => '70007','purch_amt' => '948.5','ord_date' => '2012-09-10','customer_id' => '3005','salesman_id' => '5002'),
  array('ord_no' => '70005','purch_amt' => '2400.6','ord_date' => '2012-07-27','customer_id' => '3007','salesman_id' => '5001'),
  array('ord_no' => '70008','purch_amt' => '5760','ord_date' => '2012-09-10','customer_id' => '3002','salesman_id' => '5001')
);

/* `store_database`.`salesman` */
$salesman = array(
  array('salesman_id' => '5001','name' => 'James Hoog','city' => 'New York','commission' => '0.15'),
  array('salesman_id' => '5002','name' => 'Nail Knight','city' => 'Paris','commission' => '0.13'),
  array('salesman_id' => '5005','name' => 'Pit Alex','city' => 'London','commission' => '0.11'),
  array('salesman_id' => '5006','name' => 'Mc Lyon','city' => 'Paris','commission' => '0.14'),
  array('salesman_id' => '5007','name' => 'Paul Adam','city' => 'Rome','commission' => '0.13'),
  array('salesman_id' => '5003','name' => 'Lauson Hen','city' => 'San Jose','commission' => '0.12')
);
