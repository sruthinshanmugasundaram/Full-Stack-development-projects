-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2023 at 05:45 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cust_name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `city` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `grade` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `salesman_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `cust_name`, `city`, `grade`, `salesman_id`) VALUES
('3002', 'Nick Rimando', 'New York', '100', '5001'),
('3007', 'Brad Davis', 'New York', '200', '5001'),
('3005', 'Graham Zusi', 'California', '200', '5002'),
('3008', 'Julian Green', 'London', '300', '5002'),
('3004', 'Fabian Johnson', 'Paris', '300', '5006'),
('3009', 'Geoff Cameron', 'Berlin', '100', '5003'),
('3003', 'Jozy Altidor', 'Moscow', '200', '5007');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ord_no` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `purch_amt` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ord_date` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `customer_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `salesman_id` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ord_no`, `purch_amt`, `ord_date`, `customer_id`, `salesman_id`) VALUES
('70001', '150.5', '2012-10-05', '3005', '5002'),
('70009', '270.65', '2012-09-10', '3001', '5005'),
('70002', '65.26', '2012-10-05', '3002', '5001'),
('70004', '110.5', '2012-08-17', '3009', '5003'),
('70007', '948.5', '2012-09-10', '3005', '5002'),
('70005', '2400.6', '2012-07-27', '3007', '5001'),
('70008', '5760', '2012-09-10', '3002', '5001');

-- --------------------------------------------------------

--
-- Table structure for table `salesman`
--

CREATE TABLE `salesman` (
  `salesman_id` int(20) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `city` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `commission` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `salesman`
--

INSERT INTO `salesman` (`salesman_id`, `name`, `city`, `commission`) VALUES
(5001, 'James Hoog', 'New York', '0.15'),
(5002, 'Nail Knight', 'Paris', '0.13'),
(5005, 'Pit Alex', 'London', '0.11'),
(5006, 'Mc Lyon', 'Paris', '0.14'),
(5007, 'Paul Adam', 'Rome', '0.13'),
(5003, 'Lauson Hen', 'San Jose', '0.12');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
