<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `movie_database`
 */

/* `movie_database`.`actor_table` */
$actor_table = array(
  array('act_id' => '101','act_fname' => 'James','act_iname' => 'Stewart','act_gender' => 'M','No_of_Movies' => ''),
  array('act_id' => '102','act_fname' => 'Deborah','act_iname' => 'Kerr','act_gender' => 'F','No_of_Movies' => '')
);

/* `movie_database`.`director_table` */
$director_table = array(
  array('dir_id' => '201','dir_fname' => 'Alfred','dir_lname' => 'Hitchcock'),
  array('dir_id' => '202','dir_fname' => 'Jack','dir_lname' => 'Clayton')
);

/* `movie_database`.`genre_table` */
$genre_table = array(
  array('gen_id' => '1001','gen_title' => 'Action'),
  array('gen_id' => '1002','gen_title' => 'Adventure')
);

/* `movie_database`.`movie_cast` */
$movie_cast = array(
  array('act_id' => '101','mov_id' => '901','role' => 'John Scottie Ferguso'),
  array('act_id' => '102','mov_id' => '902','role' => 'Miss Giddens')
);

/* `movie_database`.`movie_direction` */
$movie_direction = array(
  array('dir_id' => '201','mov_id' => '901'),
  array('dir_id' => '202','mov_id' => '902')
);

/* `movie_database`.`movie_genres` */
$movie_genres = array(
  array('mov_id' => '922','gen_id' => '1001'),
  array('mov_id' => '917','gen_id' => '1002')
);

/* `movie_database`.`movie_table` */
$movie_table = array(
  array('mov_id' => '901','mov_title' => 'Vertigo','mov_year' => '1958','mov_time' => '128','mov_lang' => 'English','mov_dt_rel' => '1958-08-24 ','mov_rel_country' => 'UK'),
  array('mov_id' => '915 ','mov_title' => 'Titanic','mov_year' => '1997','mov_time' => '194 ','mov_lang' => 'English','mov_dt_rel' => '1998-01-23','mov_rel_country' => 'UK')
);

/* `movie_database`.`rating` */
$rating = array(
  array('mov_id' => '901','rev_id' => '9001','stars' => '8.40','num_of_ratings' => '263575'),
  array('mov_id' => '902','rev_id' => '9002','stars' => '7.90','num_of_ratings' => '20207')
);

/* `movie_database`.`reviewer` */
$reviewer = array(
  array('rev_id' => '9001','rev_name' => 'Righty Sock'),
  array('rev_id' => '9002','rev_name' => 'Jack Malvern')
);
