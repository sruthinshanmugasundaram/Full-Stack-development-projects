-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2023 at 09:08 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `actor_table`
--

CREATE TABLE `actor_table` (
  `act_id` varchar(22) NOT NULL,
  `act_fname` varchar(20) NOT NULL,
  `act_iname` varchar(20) NOT NULL,
  `act_gender` varchar(20) NOT NULL,
  `No_of_Movies` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `actor_table`
--

INSERT INTO `actor_table` (`act_id`, `act_fname`, `act_iname`, `act_gender`, `No_of_Movies`) VALUES
('101', 'James', 'Stewart', 'M', ''),
('102', 'Deborah', 'Kerr', 'F', '');

-- --------------------------------------------------------

--
-- Table structure for table `director_table`
--

CREATE TABLE `director_table` (
  `dir_id` varchar(20) NOT NULL,
  `dir_fname` varchar(20) NOT NULL,
  `dir_lname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `director_table`
--

INSERT INTO `director_table` (`dir_id`, `dir_fname`, `dir_lname`) VALUES
('201', 'Alfred', 'Hitchcock'),
('202', 'Jack', 'Clayton');

-- --------------------------------------------------------

--
-- Table structure for table `genre_table`
--

CREATE TABLE `genre_table` (
  `gen_id` varchar(20) NOT NULL,
  `gen_title` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `genre_table`
--

INSERT INTO `genre_table` (`gen_id`, `gen_title`) VALUES
('1001', 'Action'),
('1002', 'Adventure');

-- --------------------------------------------------------

--
-- Table structure for table `movie_cast`
--

CREATE TABLE `movie_cast` (
  `act_id` varchar(20) NOT NULL,
  `mov_id` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `movie_cast`
--

INSERT INTO `movie_cast` (`act_id`, `mov_id`, `role`) VALUES
('101', '901', 'John Scottie Ferguso'),
('102', '902', 'Miss Giddens');

-- --------------------------------------------------------

--
-- Table structure for table `movie_direction`
--

CREATE TABLE `movie_direction` (
  `dir_id` varchar(20) NOT NULL,
  `mov_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `movie_direction`
--

INSERT INTO `movie_direction` (`dir_id`, `mov_id`) VALUES
('201', '901'),
('202', '902');

-- --------------------------------------------------------

--
-- Table structure for table `movie_genres`
--

CREATE TABLE `movie_genres` (
  `mov_id` varchar(20) NOT NULL,
  `gen_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `movie_genres`
--

INSERT INTO `movie_genres` (`mov_id`, `gen_id`) VALUES
('922', '1001'),
('917', '1002');

-- --------------------------------------------------------

--
-- Table structure for table `movie_table`
--

CREATE TABLE `movie_table` (
  `mov_id` varchar(20) NOT NULL,
  `mov_title` varchar(20) NOT NULL,
  `mov_year` varchar(20) NOT NULL,
  `mov_time` varchar(20) NOT NULL,
  `mov_lang` varchar(20) NOT NULL,
  `mov_dt_rel` varchar(20) NOT NULL,
  `mov_rel_country` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `movie_table`
--

INSERT INTO `movie_table` (`mov_id`, `mov_title`, `mov_year`, `mov_time`, `mov_lang`, `mov_dt_rel`, `mov_rel_country`) VALUES
('901', 'Vertigo', '1958', '128', 'English', '1958-08-24 ', 'UK'),
('915 ', 'Titanic', '1997', '194 ', 'English', '1998-01-23', 'UK');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `mov_id` varchar(20) NOT NULL,
  `rev_id` varchar(20) NOT NULL,
  `stars` varchar(20) NOT NULL,
  `num_of_ratings` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`mov_id`, `rev_id`, `stars`, `num_of_ratings`) VALUES
('901', '9001', '8.40', '263575'),
('902', '9002', '7.90', '20207');

-- --------------------------------------------------------

--
-- Table structure for table `reviewer`
--

CREATE TABLE `reviewer` (
  `rev_id` varchar(20) NOT NULL,
  `rev_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `reviewer`
--

INSERT INTO `reviewer` (`rev_id`, `rev_name`) VALUES
('9001', 'Righty Sock'),
('9002', 'Jack Malvern');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movie_cast`
--
ALTER TABLE `movie_cast`
  ADD PRIMARY KEY (`act_id`);

--
-- Indexes for table `movie_direction`
--
ALTER TABLE `movie_direction`
  ADD PRIMARY KEY (`dir_id`);

--
-- Indexes for table `movie_genres`
--
ALTER TABLE `movie_genres`
  ADD PRIMARY KEY (`gen_id`);

--
-- Indexes for table `movie_table`
--
ALTER TABLE `movie_table`
  ADD PRIMARY KEY (`mov_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`rev_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
